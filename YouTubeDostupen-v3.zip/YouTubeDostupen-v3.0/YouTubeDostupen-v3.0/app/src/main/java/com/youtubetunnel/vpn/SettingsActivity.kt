package com.youtubetunnel.vpn

import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#0F172A"))
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 52, 40, 48)
        }

        val title = TextView(this).apply {
            text = "Настройки YouTube Доступен"
            textSize = 21f
            setTextColor(Color.WHITE)
            setTypeface(null, Typeface.BOLD)
            setPadding(0, 0, 0, 24)
        }
        root.addView(title)

        // 1. Пресеты DPI
        root.addView(sectionLabel("Готовый пресет стратегии:"))
        val presetSpinner = Spinner(this).apply {
            background = roundedBg("#1E293B", 20f)
            setPadding(24, 16, 24, 16)
            adapter = ArrayAdapter(
                this@SettingsActivity,
                android.R.layout.simple_spinner_dropdown_item,
                Prefs.PRESETS.map { it.first }
            )
        }
        root.addView(presetSpinner)

        val argsEt = EditText(this).apply {
            setText(Prefs.getArgs(this@SettingsActivity))
            setTextColor(Color.WHITE)
            textSize = 12f
            background = roundedBg("#1E293B", 20f)
            setPadding(24, 20, 24, 20)
        }
        root.addView(sectionLabel("Аргументы ciadpi (можно править вручную):"))
        root.addView(argsEt)

        presetSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            var init = true
            override fun onItemSelected(p: AdapterView<*>?, v: android.view.View?, pos: Int, id: Long) {
                if (init) { init = false; return }
                argsEt.setText(Prefs.PRESETS[pos].second)
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        // 2. Стелс-режим (Split Tunneling)
        val splitSwitch = Switch(this).apply {
            text = "Стелс-режим: ТОЛЬКО выбранные приложения (Ozon, WB и банки не видят VPN)"
            setTextColor(Color.WHITE)
            isChecked = Prefs.isSplitEnabled(this@SettingsActivity)
            setPadding(0, 24, 0, 12)
        }
        root.addView(splitSwitch)

        val appsBtn = Button(this).apply {
            text = "📱 ВЫБРАТЬ ПРИЛОЖЕНИЯ (${Prefs.getSelectedApps(this@SettingsActivity).size})"
            setTextColor(Color.WHITE)
            background = roundedBg("#1E293B", 20f)
            setOnClickListener { openAppPicker(this) }
        }
        root.addView(appsBtn)

        // 3. Ускорение (IPv6)
        val ipv6Switch = Switch(this).apply {
            text = "Ускорение старта (перехват IPv6 для YouTube)"
            setTextColor(Color.WHITE)
            isChecked = Prefs.isBlockIpv6(this@SettingsActivity)
            setPadding(0, 24, 0, 8)
        }
        root.addView(ipv6Switch)

        // 4. DNS
        val dnsSwitch = Switch(this).apply {
            text = "Использовать свой DNS-сервер"
            setTextColor(Color.WHITE)
            isChecked = Prefs.isCustomDnsEnabled(this@SettingsActivity)
            setPadding(0, 16, 0, 8)
        }
        root.addView(dnsSwitch)

        val dnsEt = EditText(this).apply {
            setText(Prefs.getDns(this@SettingsActivity))
            setTextColor(Color.WHITE)
            background = roundedBg("#1E293B", 20f)
            setPadding(24, 20, 24, 20)
        }
        val dnsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 8, 0, 8)
        }
        Prefs.DNS_LIST.forEach { (label, ip) ->
            val b = Button(this).apply {
                text = label.substringBefore(" ")
                textSize = 11f
                setTextColor(Color.WHITE)
                background = roundedBg("#334155", 16f)
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = 8 }
                setOnClickListener { dnsEt.setText(ip) }
            }
            dnsRow.addView(b)
        }
        root.addView(dnsRow)
        root.addView(dnsEt)

        // 5. Порт и режим прокси
        root.addView(sectionLabel("Локальный порт SOCKS5:"))
        val portEt = EditText(this).apply {
            setText(Prefs.getPort(this@SettingsActivity).toString())
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setTextColor(Color.WHITE)
            background = roundedBg("#1E293B", 20f)
            setPadding(24, 20, 24, 20)
        }
        root.addView(portEt)

        val proxyOnlySwitch = Switch(this).apply {
            text = "Режим «Только прокси» (без VPN, 127.0.0.1)"
            setTextColor(Color.WHITE)
            isChecked = Prefs.isProxyOnly(this@SettingsActivity)
            setPadding(0, 20, 0, 24)
        }
        root.addView(proxyOnlySwitch)

        // Кнопка сохранить
        val saveBtn = Button(this).apply {
            text = "СОХРАНИТЬ НАСТРОЙКИ"
            textSize = 15f
            setTextColor(Color.WHITE)
            setTypeface(null, Typeface.BOLD)
            background = roundedBg("#16A34A", 24f)
            setPadding(0, 28, 0, 28)
            setOnClickListener {
                Prefs.setArgs(this@SettingsActivity, argsEt.text.toString())
                Prefs.setDns(this@SettingsActivity, dnsEt.text.toString().ifBlank { "1.1.1.1" })
                Prefs.setCustomDnsEnabled(this@SettingsActivity, dnsSwitch.isChecked)
                Prefs.setBlockIpv6(this@SettingsActivity, ipv6Switch.isChecked)
                Prefs.setPort(this@SettingsActivity, portEt.text.toString().toIntOrNull() ?: 1080)
                Prefs.setSplitEnabled(this@SettingsActivity, splitSwitch.isChecked)
                Prefs.setProxyOnly(this@SettingsActivity, proxyOnlySwitch.isChecked)
                Toast.makeText(this@SettingsActivity, "Сохранено! Переподключите туннель.", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
        root.addView(saveBtn)

        scroll.addView(root)
        setContentView(scroll)
    }

    private fun openAppPicker(btn: Button) {
        val pm = packageManager
        val selected = Prefs.getSelectedApps(this).toMutableSet()
        val priority = setOf(
            "com.google.android.youtube",
            "com.google.android.apps.youtube.music",
            "com.android.chrome",
            "org.telegram.messenger",
            "com.discord"
        )
        val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            .filter { pm.getLaunchIntentForPackage(it.packageName) != null && it.packageName != packageName }
            .map { it.packageName to pm.getApplicationLabel(it).toString() }
            .sortedWith(compareByDescending<Pair<String, String>> { it.first in priority }
                .thenByDescending { it.first in selected }
                .thenBy { it.second.lowercase() })

        val labels = apps.map { "${it.second}\n(${it.first})" }.toTypedArray()
        val checked = BooleanArray(apps.size) { apps[it].first in selected }

        AlertDialog.Builder(this)
            .setTitle("Приложения для туннеля")
            .setMultiChoiceItems(labels, checked) { _, which, isChecked ->
                if (isChecked) selected.add(apps[which].first)
                else selected.remove(apps[which].first)
            }
            .setPositiveButton("Готово") { _, _ ->
                Prefs.setSelectedApps(this, selected)
                btn.text = "📱 ВЫБРАТЬ ПРИЛОЖЕНИЯ (${selected.size})"
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun sectionLabel(t: String) = TextView(this).apply {
        text = t
        textSize = 13f
        setTextColor(Color.parseColor("#CBD5E1"))
        setPadding(0, 18, 0, 6)
    }

    private fun roundedBg(hex: String, radius: Float) = GradientDrawable().apply {
        setColor(Color.parseColor(hex))
        cornerRadius = radius
    }
}
