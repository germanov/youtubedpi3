package com.youtubetunnel.vpn

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    private lateinit var statusTv: TextView
    private lateinit var statsTv: TextView
    private lateinit var modeBadgeTv: TextView
    private lateinit var mainBtn: Button
    private lateinit var argsEt: EditText
    private lateinit var logTv: TextView
    private lateinit var logScroll: ScrollView

    private val vpnPermLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { res ->
        if (res.resultCode == RESULT_OK) startVpnService()
        else TunnelState.log("Пользователь отклонил разрешение VPN")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        observeState()
    }

    override fun onResume() {
        super.onResume()
        argsEt.setText(Prefs.getArgs(this))
        updateModeBadge()
    }

    private fun updateModeBadge() {
        val text = when {
            Prefs.isProxyOnly(this) -> "Режим: Только прокси (127.0.0.1:${Prefs.getPort(this)})"
            Prefs.isSplitEnabled(this) -> "Стелс-режим: только выбранные (${Prefs.getSelectedApps(this).size} прил.) • Ozon/WB напрямую"
            else -> "Режим: весь трафик телефона"
        }
        modeBadgeTv.text = text
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#0F172A"))
            setPadding(40, 52, 40, 28)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(this).apply {
            text = "YouTube Доступен"
            textSize = 23f
            setTextColor(Color.WHITE)
            setTypeface(null, Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val settingsBtn = Button(this).apply {
            text = "⚙ Настройки"
            setTextColor(Color.WHITE)
            background = roundedBg("#1E293B", 24f)
            setOnClickListener { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) }
        }
        header.addView(title)
        header.addView(settingsBtn)
        root.addView(header)

        statusTv = TextView(this).apply {
            text = "Отключено"
            textSize = 18f
            setTextColor(Color.parseColor("#94A3B8"))
            gravity = Gravity.CENTER
            setPadding(0, 20, 0, 4)
        }
        statsTv = TextView(this).apply {
            text = "↓ 0 Кбит/с  ↑ 0 Кбит/с  |  YouTube: —"
            textSize = 13f
            setTextColor(Color.parseColor("#38BDF8"))
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 6)
        }
        modeBadgeTv = TextView(this).apply {
            textSize = 12f
            setTextColor(Color.parseColor("#4ADE80"))
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 20)
        }
        root.addView(statusTv)
        root.addView(statsTv)
        root.addView(modeBadgeTv)
        updateModeBadge()

        mainBtn = Button(this).apply {
            text = "ПОДКЛЮЧИТЬ"
            textSize = 16f
            setTextColor(Color.WHITE)
            setTypeface(null, Typeface.BOLD)
            background = roundedBg("#EF4444", 28f)
            setPadding(0, 32, 0, 32)
            setOnClickListener {
                Prefs.setArgs(this@MainActivity, argsEt.text.toString())
                if (TunnelState.isConnected.value) stopVpnService()
                else requestAndStart()
            }
        }
        root.addView(mainBtn)

        val rowBtns = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 18, 0, 14)
        }
        val testBtn = Button(this).apply {
            text = "🔍 ПОДОБРАТЬ"
            setTextColor(Color.WHITE)
            background = roundedBg("#0F766E", 24f)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = 10 }
            setOnClickListener { runAutoTune() }
        }
        val checkBtn = Button(this).apply {
            text = "⚡ ТЕСТ YT"
            setTextColor(Color.WHITE)
            background = roundedBg("#334155", 24f)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = 10 }
            setOnClickListener {
                lifecycleScope.launch {
                    val ms = StrategyTester.checkYouTubeViaProxy(Prefs.getPort(this@MainActivity))
                    TunnelState.youtubePing.value = if (ms > 0) "${ms} мс" else "Нет ответа"
                    TunnelState.log(if (ms > 0) "⚡ Тест YouTube: OK (${ms} мс)" else "✗ Тест YouTube: не отвечает")
                }
            }
        }
        rowBtns.addView(testBtn)
        rowBtns.addView(checkBtn)
        root.addView(rowBtns)

        val labelArgs = TextView(this).apply {
            text = "Активные аргументы обхода (ciadpi):"
            textSize = 12f
            setTextColor(Color.parseColor("#CBD5E1"))
            setPadding(0, 2, 0, 6)
        }
        argsEt = EditText(this).apply {
            setText(Prefs.getArgs(this@MainActivity))
            setTextColor(Color.WHITE)
            textSize = 12f
            maxLines = 3
            background = roundedBg("#1E293B", 20f)
            setPadding(24, 18, 24, 18)
        }
        root.addView(labelArgs)
        root.addView(argsEt)

        val logHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 18, 0, 6)
        }
        val logLabel = TextView(this).apply {
            text = "Журнал:"
            textSize = 12f
            setTextColor(Color.parseColor("#CBD5E1"))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val copyBtn = TextView(this).apply {
            text = "Копировать"
            textSize = 12f
            setTextColor(Color.parseColor("#38BDF8"))
            setPadding(16, 6, 16, 6)
            setOnClickListener {
                val cm = getSystemService(ClipboardManager::class.java)
                cm.setPrimaryClip(ClipData.newPlainText("log", TunnelState.logs.value))
                Toast.makeText(this@MainActivity, "Журнал скопирован", Toast.LENGTH_SHORT).show()
            }
        }
        val clearBtn = TextView(this).apply {
            text = "Очистить"
            textSize = 12f
            setTextColor(Color.parseColor("#F87171"))
            setPadding(16, 6, 0, 6)
            setOnClickListener { TunnelState.clearLogs() }
        }
        logHeader.addView(logLabel)
        logHeader.addView(copyBtn)
        logHeader.addView(clearBtn)
        root.addView(logHeader)

        logScroll = ScrollView(this).apply {
            background = roundedBg("#0B1120", 20f)
            setPadding(22, 18, 22, 18)
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        logTv = TextView(this).apply {
            textSize = 11f
            setTextColor(Color.parseColor("#E2E8F0"))
            typeface = Typeface.MONOSPACE
        }
        logScroll.addView(logTv)
        root.addView(logScroll)

        setContentView(root)
    }

    private fun observeState() {
        lifecycleScope.launch {
            TunnelState.isConnected.collect { connected ->
                mainBtn.text = if (connected) "ОТКЛЮЧИТЬ" else "ПОДКЛЮЧИТЬ"
                mainBtn.background = roundedBg(if (connected) "#DC2626" else "#2563EB", 28f)
                statusTv.setTextColor(Color.parseColor(if (connected) "#4ADE80" else "#94A3B8"))
            }
        }
        lifecycleScope.launch {
            TunnelState.statusText.collect { statusTv.text = it }
        }
        lifecycleScope.launch {
            combine(TunnelState.rxKbps, TunnelState.txKbps, TunnelState.youtubePing) { rx, tx, ping ->
                "↓ $rx Кбит/с  ↑ $tx Кбит/с  |  YouTube: $ping"
            }.collect { statsTv.text = it }
        }
        lifecycleScope.launch {
            TunnelState.logs.collect {
                logTv.text = it
                logScroll.post { logScroll.fullScroll(ScrollView.FOCUS_DOWN) }
            }
        }
    }

    private fun runAutoTune() {
        lifecycleScope.launch {
            if (TunnelState.isConnected.value) stopVpnService()
            val best = StrategyTester.findBestStrategy(this@MainActivity)
            if (best != null) {
                Prefs.setArgs(this@MainActivity, best)
                argsEt.setText(best)
                Toast.makeText(this@MainActivity, "Выбрана лучшая стратегия!", Toast.LENGTH_SHORT).show()
                requestAndStart()
            }
        }
    }

    private fun requestAndStart() {
        if (Prefs.isProxyOnly(this)) {
            startVpnService()
            return
        }
        val intent = VpnService.prepare(this)
        if (intent != null) vpnPermLauncher.launch(intent)
        else startVpnService()
    }

    private fun startVpnService() {
        val i = Intent(this, TunnelVpnService::class.java).setAction(TunnelVpnService.ACTION_START)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i)
        else startService(i)
    }

    private fun stopVpnService() {
        startService(Intent(this, TunnelVpnService::class.java).setAction(TunnelVpnService.ACTION_STOP))
    }

    private fun roundedBg(hex: String, radius: Float) = GradientDrawable().apply {
        setColor(Color.parseColor(hex))
        cornerRadius = radius
    }
}
