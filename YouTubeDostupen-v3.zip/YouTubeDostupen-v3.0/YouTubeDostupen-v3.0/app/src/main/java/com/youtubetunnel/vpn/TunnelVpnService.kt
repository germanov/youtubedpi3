package com.youtubetunnel.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import kotlinx.coroutines.*
import java.io.File

class TunnelVpnService : VpnService() {
    companion object {
        const val ACTION_START = "START"
        const val ACTION_STOP = "STOP"
        private const val CHANNEL_ID = "yt_dostupen_v3_channel"
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var vpnInterface: ParcelFileDescriptor? = null
    private var dpiEngine: ByeDpiEngine? = null
    private var statsJob: Job? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopTunnel()
            else -> startTunnel()
        }
        return START_STICKY
    }

    private fun startTunnel() {
        stopInternal()
        startForeground(1, buildNotification("Запуск YouTube Доступен..."))
        TunnelState.statusText.value = "Запуск движка..."

        scope.launch {
            val port = Prefs.getPort(this@TunnelVpnService)
            val args = Prefs.getArgs(this@TunnelVpnService)
            val dns = Prefs.getDns(this@TunnelVpnService)
            val useCustomDns = Prefs.isCustomDnsEnabled(this@TunnelVpnService)
            val blockIpv6 = Prefs.isBlockIpv6(this@TunnelVpnService)
            val proxyOnly = Prefs.isProxyOnly(this@TunnelVpnService)

            val engine = ByeDpiEngine(this@TunnelVpnService)
            if (!engine.start(port, args)) {
                TunnelState.statusText.value = "Ошибка запуска движка"
                TunnelState.isConnected.value = false
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return@launch
            }
            dpiEngine = engine
            TunnelState.log("✓ ciadpi активен на 127.0.0.1:$port")

            if (proxyOnly) {
                TunnelState.isConnected.value = true
                TunnelState.statusText.value = "Прокси активен (127.0.0.1:$port)"
                updateNotification("Прокси 127.0.0.1:$port активен")
                val ping = StrategyTester.checkYouTubeViaProxy(port)
                TunnelState.youtubePing.value = if (ping > 0) "${ping} мс" else "Нет ответа"
                TunnelState.log(if (ping > 0) "✓ Прокси работает, YouTube: ${ping} мс" else "⚠ Прокси запущен, но YouTube не ответил")
                return@launch
            }

            val builder = Builder()
                .setSession("YouTube Доступен")
                .setMtu(1500)
                .addAddress("10.10.10.2", 32)
                .addRoute("0.0.0.0", 0)

            // Захват IPv6 предотвращает 10-секундные зависания YouTube при попытке идти в обход туннеля
            if (blockIpv6) {
                builder.addAddress("fd00::2", 128)
                builder.addRoute("::", 0)
            }

            if (useCustomDns && dns.isNotBlank()) {
                try {
                    builder.addDnsServer(dns)
                    TunnelState.log("DNS: $dns")
                } catch (e: Exception) {
                    TunnelState.log("Неверный DNS ($dns), используется системный")
                }
            }

            if (Prefs.isSplitEnabled(this@TunnelVpnService)) {
                val apps = Prefs.getSelectedApps(this@TunnelVpnService)
                var added = 0
                for (pkg in apps) {
                    if (pkg == packageName) continue
                    try {
                        builder.addAllowedApplication(pkg)
                        added++
                    } catch (_: Exception) {}
                }
                if (added > 0) {
                    TunnelState.log("✓ Стелс-режим: туннель ТОЛЬКО для $added прил. (Ozon/WB/банки напрямую)")
                } else {
                    builder.addDisallowedApplication(packageName)
                    TunnelState.log("⚠ Приложения не найдены — включён режим «Весь трафик»")
                }
            } else {
                builder.addDisallowedApplication(packageName)
                TunnelState.log("Режим: весь трафик телефона")
            }

            val pfd = builder.establish()
            if (pfd == null) {
                TunnelState.log("ОШИБКА: Android не выдал VPN-интерфейс")
                stopTunnel()
                return@launch
            }
            vpnInterface = pfd

            val cfgFile = File(cacheDir, "hev_tproxy.yml")
            cfgFile.writeText(
                """
                tunnel:
                  mtu: 1500
                socks5:
                  port: $port
                  address: 127.0.0.1
                  udp: 'udp'
                misc:
                  task-stack-size: 81920
                  connect-timeout: 4000
                  read-write-timeout: 60000
                  log-level: warn
                """.trimIndent()
            )

            try {
                TProxyService.TProxyStartService(cfgFile.absolutePath, pfd.fd)
            } catch (e: Throwable) {
                TunnelState.log("ОШИБКА tun2socks: ${e.message}")
                stopTunnel()
                return@launch
            }

            TunnelState.isConnected.value = true
            TunnelState.statusText.value = "YouTube Доступен ✓"
            TunnelState.log("✓ Туннель запущен (MTU 1500)")
            updateNotification("Активно • Только выбранные приложения")

            val ping = StrategyTester.checkYouTubeViaProxy(port)
            TunnelState.youtubePing.value = if (ping > 0) "${ping} мс" else "Таймаут"
            TunnelState.log(if (ping > 0) "⚡ YouTube отвечает за ${ping} мс" else "⚠ YouTube не ответил — нажмите «Подобрать»")

            startStatsLoop()
        }
    }

    private fun startStatsLoop() {
        statsJob?.cancel()
        statsJob = scope.launch {
            var prevTx = 0L
            var prevRx = 0L
            while (isActive && TunnelState.isConnected.value) {
                try {
                    val s = TProxyService.TProxyGetStats()
                    if (s.size >= 4) {
                        val tx = s[1]
                        val rx = s[3]
                        if (prevRx > 0 || prevTx > 0) {
                            TunnelState.txKbps.value = ((tx - prevTx).coerceAtLeast(0L) * 8) / 1024
                            TunnelState.rxKbps.value = ((rx - prevRx).coerceAtLeast(0L) * 8) / 1024
                        }
                        prevTx = tx
                        prevRx = rx
                    }
                } catch (_: Throwable) {}
                delay(1000)
            }
        }
    }

    private fun stopInternal() {
        statsJob?.cancel()
        try { TProxyService.TProxyStopService() } catch (_: Throwable) {}
        try { vpnInterface?.close() } catch (_: Exception) {}
        vpnInterface = null
        dpiEngine?.stop()
        dpiEngine = null
        TunnelState.isConnected.value = false
        TunnelState.rxKbps.value = 0
        TunnelState.txKbps.value = 0
        TunnelState.youtubePing.value = "—"
    }

    private fun stopTunnel() {
        stopInternal()
        TunnelState.statusText.value = "Отключено"
        TunnelState.log("Туннель остановлен.")
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun buildNotification(text: String): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "YouTube Доступен", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val b = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION") Notification.Builder(this)
        }
        return b.setContentTitle("YouTube Доступен")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(pi)
            .build()
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java).notify(1, buildNotification(text))
    }

    override fun onDestroy() {
        stopInternal()
        scope.cancel()
        super.onDestroy()
    }
}
