package com.youtubetunnel.vpn

import kotlinx.coroutines.flow.MutableStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object TunnelState {
    val isConnected = MutableStateFlow(false)
    val statusText = MutableStateFlow("Отключено")
    val rxKbps = MutableStateFlow(0L)
    val txKbps = MutableStateFlow(0L)
    val youtubePing = MutableStateFlow("—")
    val logs = MutableStateFlow("YouTube Доступен v3.0 готов. По умолчанию работает ТОЛЬКО для YouTube (Ozon/WB/банки не затронуты).")

    private val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    fun log(msg: String) {
        val line = "[${timeFmt.format(Date())}] $msg"
        val cur = logs.value
        val lines = (if (cur.isEmpty()) listOf(line) else cur.split("\n") + line).takeLast(120)
        logs.value = lines.joinToString("\n")
    }

    fun clearLogs() {
        logs.value = ""
    }
}
