package com.youtubetunnel.vpn

import android.content.Context
import java.io.File
import java.net.InetSocketAddress
import java.net.Socket

class ByeDpiEngine(private val ctx: Context) {
    private var process: Process? = null

    fun start(port: Int, rawArgs: String): Boolean {
        stop()
        val bin = File(ctx.applicationInfo.nativeLibraryDir, "libciadpi.so")
        if (!bin.exists()) {
            TunnelState.log("ОШИБКА: не найден движок libciadpi.so")
            return false
        }
        val cmd = mutableListOf(bin.absolutePath, "-i", "127.0.0.1", "-p", port.toString())
        rawArgs.trim().split(Regex("\\s+")).filter { it.isNotBlank() }.forEach { cmd.add(it) }

        TunnelState.log("Запуск ciadpi на порту $port...")
        return try {
            val pb = ProcessBuilder(cmd).redirectErrorStream(true)
            process = pb.start()
            val ok = waitForPort(port, 3000)
            if (!ok) {
                TunnelState.log("ОШИБКА: ciadpi не открыл порт $port (проверьте аргументы)")
                stop()
            }
            ok
        } catch (e: Exception) {
            TunnelState.log("Ошибка запуска ciadpi: ${e.message}")
            stop()
            false
        }
    }

    private fun waitForPort(port: Int, timeoutMs: Long): Boolean {
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline) {
            if (process?.isAlive == false) return false
            try {
                Socket().use { s ->
                    s.connect(InetSocketAddress("127.0.0.1", port), 150)
                    return true
                }
            } catch (_: Exception) {
                Thread.sleep(80)
            }
        }
        return false
    }

    fun stop() {
        try {
            process?.destroy()
            process?.destroyForcibly()
        } catch (_: Exception) {}
        process = null
    }
}
