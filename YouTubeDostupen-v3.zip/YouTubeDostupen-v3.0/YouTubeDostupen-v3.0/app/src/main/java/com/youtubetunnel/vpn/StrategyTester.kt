package com.youtubetunnel.vpn

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Proxy
import java.net.URL

object StrategyTester {
    suspend fun checkYouTubeViaProxy(port: Int): Long = withContext(Dispatchers.IO) {
        val start = System.currentTimeMillis()
        try {
            val proxy = Proxy(Proxy.Type.SOCKS, InetSocketAddress("127.0.0.1", port))
            val conn = (URL("https://www.youtube.com/generate_204").openConnection(proxy) as HttpURLConnection).apply {
                connectTimeout = 4000
                readTimeout = 4000
                instanceFollowRedirects = false
                requestMethod = "GET"
            }
            val code = conn.responseCode
            conn.disconnect()
            if (code in 200..399) System.currentTimeMillis() - start else -1L
        } catch (_: Exception) {
            -1L
        }
    }

    suspend fun findBestStrategy(ctx: Context): String? = withContext(Dispatchers.IO) {
        val testPort = 1091
        val engine = ByeDpiEngine(ctx)
        TunnelState.log("--- Поиск самой быстрой стратегии ---")
        var bestArgs: String? = null
        var bestMs = Long.MAX_VALUE

        for ((name, args) in Prefs.PRESETS) {
            TunnelState.log("Тест: $name")
            if (!engine.start(testPort, args)) {
                TunnelState.log("  ✗ Движок не стартовал")
                continue
            }
            val ms = checkYouTubeViaProxy(testPort)
            engine.stop()
            if (ms > 0) {
                TunnelState.log("  ✓ Ответ YouTube: ${ms} мс")
                if (ms < bestMs) {
                    bestMs = ms
                    bestArgs = args
                }
                if (ms < 450) {
                    TunnelState.log("  ⚡ Отличная скорость! Выбираем эту стратегию.")
                    break
                }
            } else {
                TunnelState.log("  ✗ Таймаут")
            }
        }
        if (bestArgs != null) {
            TunnelState.youtubePing.value = "${bestMs} мс"
        } else {
            TunnelState.log("Ни один пресет не ответил. Проверьте интернет.")
        }
        bestArgs
    }
}
