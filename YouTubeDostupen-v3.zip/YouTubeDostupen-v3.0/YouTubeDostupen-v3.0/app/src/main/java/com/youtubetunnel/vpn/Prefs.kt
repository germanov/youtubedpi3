package com.youtubetunnel.vpn

import android.content.Context

object Prefs {
    private const val NAME = "yt_dostupen_v3_prefs"

    const val DEFAULT_ARGS = "-d1 -d3+s -s6+s -d9+s -s12+s -d15+s -s20+s -d25+s -s30+s -d35+s -r1+s -S -a1 -As -d1 -d3+s -s6+s -d9+s -s12+s -d15+s -s20+s -d25+s -s30+s -d35+s -S -a1"

    val PRESETS = listOf(
        "Турбо РФ (ByeByeDPI Проверенный)" to DEFAULT_ARGS,
        "Быстрый OOB + TLSRec + UDP" to "-o1 -r1+s -S -a1 -As -o1 -r1+s -a1",
        "Disorder + Split + TLSRec" to "-d1 -s2+s -r1+s -S -a1",
        "Fake TTL 8 + Disorder + TLSRec" to "-f-1 -t8 -d1 -r1+s -a1",
        "Fake TTL 5 + OOB + TLSRec" to "-f-1 -t5 -o1 -r1+s -a1",
        "Агрессивный мульти-сплит" to "-s1 -d2+s -s5+s -d10+s -r1+s -S -a1"
    )

    val DNS_LIST = listOf(
        "Cloudflare (1.1.1.1)" to "1.1.1.1",
        "Google (8.8.8.8)" to "8.8.8.8",
        "AdGuard (94.140.14.14)" to "94.140.14.14",
        "Quad9 (9.9.9.9)" to "9.9.9.9"
    )

    fun getArgs(ctx: Context): String =
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE)
            .getString("dpi_args", DEFAULT_ARGS) ?: DEFAULT_ARGS

    fun setArgs(ctx: Context, args: String) {
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE)
            .edit().putString("dpi_args", args.trim()).apply()
    }

    fun getPort(ctx: Context): Int =
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).getInt("port", 1080)

    fun setPort(ctx: Context, port: Int) {
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE)
            .edit().putInt("port", port).apply()
    }

    fun getDns(ctx: Context): String =
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE)
            .getString("dns", "1.1.1.1") ?: "1.1.1.1"

    fun setDns(ctx: Context, dns: String) {
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE)
            .edit().putString("dns", dns.trim()).apply()
    }

    fun isCustomDnsEnabled(ctx: Context): Boolean =
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE)
            .getBoolean("custom_dns", true)

    fun setCustomDnsEnabled(ctx: Context, enabled: Boolean) {
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE)
            .edit().putBoolean("custom_dns", enabled).apply()
    }

    fun isBlockIpv6(ctx: Context): Boolean =
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE)
            .getBoolean("block_ipv6", true)

    fun setBlockIpv6(ctx: Context, enabled: Boolean) {
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE)
            .edit().putBoolean("block_ipv6", enabled).apply()
    }

    fun isSplitEnabled(ctx: Context): Boolean =
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE)
            .getBoolean("split_enabled", true)

    fun setSplitEnabled(ctx: Context, enabled: Boolean) {
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE)
            .edit().putBoolean("split_enabled", enabled).apply()
    }

    fun isProxyOnly(ctx: Context): Boolean =
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE)
            .getBoolean("proxy_only", false)

    fun setProxyOnly(ctx: Context, enabled: Boolean) {
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE)
            .edit().putBoolean("proxy_only", enabled).apply()
    }

    fun getSelectedApps(ctx: Context): Set<String> {
        // Строго YouTube по умолчанию — Ozon, WB, банки вообще не видят VPN
        val def = setOf("com.google.android.youtube")
        return ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE)
            .getStringSet("selected_apps", def) ?: def
    }

    fun setSelectedApps(ctx: Context, apps: Set<String>) {
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE)
            .edit().putStringSet("selected_apps", apps).apply()
    }
}
